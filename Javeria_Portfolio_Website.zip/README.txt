JAVERIA PORTFOLIO WEBSITE

1. Open index.html in a browser to preview the website.
2. The website is responsive for mobile and desktop.
3. Replace the sample portfolio cards with your actual design images when you have them.
4. The WhatsApp and email buttons already use the contact details provided.
5. To publish it, upload index.html to a static hosting service such as GitHub Pages, Netlify, or Vercel.
